__author__ = "Fidel A. Guerrero Pena"
__copyright__ = "Copyright 2020"
__credits__ = ["Fidel A. Guerrero Pena"]
__license__ = "MIT"
__version__ = "0.0.1"
__maintainer__ = "Fidel A. Guerrero Pena"
__email__ = "fagp@cin.ufpe.br"
__status__ = "Development"
