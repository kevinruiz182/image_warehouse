from .src.train import main as train
